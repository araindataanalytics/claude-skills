# Impact Wolves Claude Skills

Sample Claude skills repository with a GitHub Pages download catalog.

## Publish

1. Create a GitHub repository named `skills` (private if your plan supports Pages from private repositories).
2. Upload the **contents** of this folder to the repository root.
3. Go to Settings → Pages → Deploy from a branch; select `main` and `/docs`.
4. Open `https://YOUR-USERNAME.github.io/skills/`.

The website and ZIP downloads are public to anyone with their URLs. `noindex` and robots.txt only discourage search indexing; they do not enforce privacy.

## Skills

- amazon-ppc-analysis — sample advertising diagnostics
- data-validation — sample tabular data checks
- n8n-automation — sample n8n workflow review

Each download ZIP includes a top-level skill folder containing SKILL.md.
