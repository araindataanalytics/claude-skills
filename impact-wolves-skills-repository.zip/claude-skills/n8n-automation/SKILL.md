---
name: n8n-automation
description: Review n8n workflows for correctness, reliability and maintainability.
---

# n8n Automation

Inspect trigger conditions, item shapes, expressions, branching, pagination, retries, timeouts, and credentials handling. Recommend idempotency for write operations, bounded retries with backoff, and actionable error logs. Never expose secrets or assume an external API contract without evidence.
